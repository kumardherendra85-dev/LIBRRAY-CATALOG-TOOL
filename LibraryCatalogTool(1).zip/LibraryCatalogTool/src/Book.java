/**
 * Book.java
 * Model class representing a Book entity in the library catalog.
 * Demonstrates encapsulation (private fields + public getters/setters)
 * and input validation via a custom checked exception.
 */
public class Book {

    private String isbn;
    private String title;
    private String author;
    private String genre;
    private int year;
    private int totalCopies;
    private int availableCopies;

    public Book(String isbn, String title, String author, String genre,
                int year, int totalCopies, int availableCopies) throws InvalidBookDataException {
        setIsbn(isbn);
        setTitle(title);
        setAuthor(author);
        setGenre(genre);
        setYear(year);
        setTotalCopies(totalCopies);
        setAvailableCopies(availableCopies);
    }

    /** Convenience constructor for creating a brand-new catalog entry (all copies available). */
    public Book(String isbn, String title, String author, String genre,
                int year, int totalCopies) throws InvalidBookDataException {
        this(isbn, title, author, genre, year, totalCopies, totalCopies);
    }

    // ---------- Getters ----------
    public String getIsbn() { return isbn; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public String getGenre() { return genre; }
    public int getYear() { return year; }
    public int getTotalCopies() { return totalCopies; }
    public int getAvailableCopies() { return availableCopies; }

    // ---------- Setters (with validation) ----------
    public void setIsbn(String isbn) throws InvalidBookDataException {
        if (isbn == null || !isbn.trim().matches("^[0-9Xx-]{10,17}$")) {
            throw new InvalidBookDataException("ISBN must be 10-17 characters (digits, hyphens, optional trailing X).");
        }
        this.isbn = isbn.trim();
    }

    public void setTitle(String title) throws InvalidBookDataException {
        if (title == null || title.trim().isEmpty()) {
            throw new InvalidBookDataException("Title cannot be empty.");
        }
        this.title = title.trim();
    }

    public void setAuthor(String author) throws InvalidBookDataException {
        if (author == null || author.trim().isEmpty()) {
            throw new InvalidBookDataException("Author cannot be empty.");
        }
        this.author = author.trim();
    }

    public void setGenre(String genre) throws InvalidBookDataException {
        if (genre == null || genre.trim().isEmpty()) {
            throw new InvalidBookDataException("Genre cannot be empty.");
        }
        this.genre = genre.trim();
    }

    public void setYear(int year) throws InvalidBookDataException {
        if (year < 1450 || year > 2100) {
            throw new InvalidBookDataException("Publication year must be between 1450 and 2100.");
        }
        this.year = year;
    }

    public void setTotalCopies(int totalCopies) throws InvalidBookDataException {
        if (totalCopies < 0) {
            throw new InvalidBookDataException("Total copies cannot be negative.");
        }
        this.totalCopies = totalCopies;
    }

    public void setAvailableCopies(int availableCopies) throws InvalidBookDataException {
        if (availableCopies < 0 || availableCopies > totalCopies) {
            throw new InvalidBookDataException("Available copies must be between 0 and total copies.");
        }
        this.availableCopies = availableCopies;
    }

    /** Marks one copy as checked out. */
    public void checkout() throws InvalidBookDataException {
        if (availableCopies <= 0) {
            throw new InvalidBookDataException("No available copies of '" + title + "' to check out.");
        }
        availableCopies--;
    }

    /** Marks one copy as returned. */
    public void returnCopy() throws InvalidBookDataException {
        if (availableCopies >= totalCopies) {
            throw new InvalidBookDataException("All copies of '" + title + "' are already checked in.");
        }
        availableCopies++;
    }

    public boolean isAvailable() {
        return availableCopies > 0;
    }

    /** Converts the book's data into a CSV-safe line for file storage. */
    public String toCsvLine() {
        return isbn + "," + escape(title) + "," + escape(author) + "," + escape(genre) + "," +
                year + "," + totalCopies + "," + availableCopies;
    }

    private String escape(String value) {
        // Commas inside fields are replaced to keep the simple CSV format intact.
        return value.replace(",", ";");
    }

    @Override
    public String toString() {
        return "Book{isbn='" + isbn + "', title='" + title + "', author='" + author +
                "', genre='" + genre + "', year=" + year + ", totalCopies=" + totalCopies +
                ", availableCopies=" + availableCopies + '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Book)) return false;
        return isbn.equalsIgnoreCase(((Book) obj).isbn);
    }

    @Override
    public int hashCode() {
        return isbn.toLowerCase().hashCode();
    }
}
