/**
 * InvalidBookDataException.java
 * Custom checked exception thrown when book data fails validation,
 * or when an illegal catalog operation is attempted (e.g. checking
 * out a book with zero available copies).
 */
public class InvalidBookDataException extends Exception {
    public InvalidBookDataException(String message) {
        super(message);
    }
}
