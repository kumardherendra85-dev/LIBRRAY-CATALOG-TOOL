import java.io.*;
import java.util.*;

/**
 * LibraryCatalogManager.java
 * Handles all CRUD and checkout/return operations on Book objects and
 * persists the catalog to a CSV file. Demonstrates the Java Collections
 * Framework (ArrayList, HashMap) and file I/O with proper exception handling.
 */
public class LibraryCatalogManager {

    private final List<Book> books;             // ordered storage
    private final Map<String, Book> isbnIndex;   // fast lookup by ISBN
    private final String filePath;

    public LibraryCatalogManager(String filePath) {
        this.filePath = filePath;
        this.books = new ArrayList<>();
        this.isbnIndex = new HashMap<>();
        loadFromFile();
    }

    /** Adds a new book. Throws if a book with the same ISBN already exists. */
    public void addBook(Book book) throws InvalidBookDataException {
        if (isbnIndex.containsKey(book.getIsbn().toLowerCase())) {
            throw new InvalidBookDataException("A book with ISBN '" + book.getIsbn() + "' already exists.");
        }
        books.add(book);
        isbnIndex.put(book.getIsbn().toLowerCase(), book);
        saveToFile();
    }

    /** Updates an existing book's details (identified by ISBN). */
    public void updateBook(Book updated) throws InvalidBookDataException {
        Book existing = isbnIndex.get(updated.getIsbn().toLowerCase());
        if (existing == null) {
            throw new InvalidBookDataException("No book found with ISBN '" + updated.getIsbn() + "'.");
        }
        int index = books.indexOf(existing);
        books.set(index, updated);
        isbnIndex.put(updated.getIsbn().toLowerCase(), updated);
        saveToFile();
    }

    /** Deletes a book by ISBN. Returns true if a book was removed. */
    public boolean deleteBook(String isbn) {
        Book existing = isbnIndex.remove(isbn.toLowerCase());
        if (existing == null) return false;
        books.remove(existing);
        saveToFile();
        return true;
    }

    /** Checks out one copy of the given book. */
    public void checkout(String isbn) throws InvalidBookDataException {
        Book book = isbnIndex.get(isbn.toLowerCase());
        if (book == null) {
            throw new InvalidBookDataException("No book found with ISBN '" + isbn + "'.");
        }
        book.checkout();
        saveToFile();
    }

    /** Returns (checks in) one copy of the given book. */
    public void returnBook(String isbn) throws InvalidBookDataException {
        Book book = isbnIndex.get(isbn.toLowerCase());
        if (book == null) {
            throw new InvalidBookDataException("No book found with ISBN '" + isbn + "'.");
        }
        book.returnCopy();
        saveToFile();
    }

    public Book getBookByIsbn(String isbn) {
        return isbnIndex.get(isbn.toLowerCase());
    }

    /** Searches by title, author, or genre (case-insensitive substring match). */
    public List<Book> search(String keyword) {
        List<Book> results = new ArrayList<>();
        String lower = keyword.toLowerCase();
        for (Book b : books) {
            if (b.getTitle().toLowerCase().contains(lower) ||
                    b.getAuthor().toLowerCase().contains(lower) ||
                    b.getGenre().toLowerCase().contains(lower)) {
                results.add(b);
            }
        }
        return results;
    }

    /** Returns only books that currently have at least one available copy. */
    public List<Book> getAvailableBooks() {
        List<Book> results = new ArrayList<>();
        for (Book b : books) {
            if (b.isAvailable()) results.add(b);
        }
        return results;
    }

    /** Returns an unmodifiable view of all books, sorted by title. */
    public List<Book> getAllBooks() {
        List<Book> sorted = new ArrayList<>(books);
        sorted.sort(Comparator.comparing(Book::getTitle, String.CASE_INSENSITIVE_ORDER));
        return sorted;
    }

    public int getTotalTitles() {
        return books.size();
    }

    public int getTotalCopies() {
        int sum = 0;
        for (Book b : books) sum += b.getTotalCopies();
        return sum;
    }

    public int getTotalAvailable() {
        int sum = 0;
        for (Book b : books) sum += b.getAvailableCopies();
        return sum;
    }

    /** Persists the current in-memory catalog to the CSV file. */
    private void saveToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write("isbn,title,author,genre,year,totalCopies,availableCopies");
            writer.newLine();
            for (Book b : books) {
                writer.write(b.toCsvLine());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving catalog data: " + e.getMessage());
        }
    }

    /** Loads the catalog from the CSV file, if it exists. */
    private void loadFromFile() {
        File file = new File(filePath);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line = reader.readLine(); // skip header
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] parts = line.split(",", -1);
                if (parts.length != 7) continue; // skip malformed rows
                try {
                    Book b = new Book(
                            parts[0], parts[1], parts[2], parts[3],
                            Integer.parseInt(parts[4]),
                            Integer.parseInt(parts[5]),
                            Integer.parseInt(parts[6])
                    );
                    books.add(b);
                    isbnIndex.put(b.getIsbn().toLowerCase(), b);
                } catch (InvalidBookDataException | NumberFormatException e) {
                    System.err.println("Skipping invalid record: " + line + " (" + e.getMessage() + ")");
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading catalog data: " + e.getMessage());
        }
    }
}
