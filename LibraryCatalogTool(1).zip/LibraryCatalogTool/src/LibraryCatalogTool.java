import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * LibraryCatalogTool.java
 * Main application class. Builds a Swing GUI (Delegation Event Model,
 * layout managers, JTable) on top of LibraryCatalogManager for cataloguing,
 * searching, and checking books in/out, with data persisted to catalog.csv.
 *
 * CODTECH Internship - Java Domain
 * Author: Abhay
 */
public class LibraryCatalogTool extends JFrame {

    private final LibraryCatalogManager catalogManager;

    // Form fields
    private JTextField isbnField, titleField, authorField, genreField, yearField, totalCopiesField;
    private JTextField searchField;

    // Table
    private JTable table;
    private DefaultTableModel tableModel;

    // Status
    private JLabel statusLabel;

    private static final String[] COLUMNS =
            {"ISBN", "Title", "Author", "Genre", "Year", "Total Copies", "Available"};

    public LibraryCatalogTool() {
        super("Library Catalog Tool");
        catalogManager = new LibraryCatalogManager("catalog.csv");

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1050, 620);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        add(buildFormPanel(), BorderLayout.NORTH);
        add(buildTablePanel(), BorderLayout.CENTER);
        add(buildButtonPanel(), BorderLayout.SOUTH);

        refreshTable();
    }

    // ---------------------------------------------------------------
    // UI construction
    // ---------------------------------------------------------------

    private JPanel buildFormPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Book Details"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        isbnField = new JTextField(14);
        titleField = new JTextField(18);
        authorField = new JTextField(15);
        genreField = new JTextField(12);
        yearField = new JTextField(6);
        totalCopiesField = new JTextField(5);

        addFormField(panel, gbc, 0, 0, "ISBN:", isbnField);
        addFormField(panel, gbc, 2, 0, "Title:", titleField);
        addFormField(panel, gbc, 4, 0, "Author:", authorField);

        addFormField(panel, gbc, 0, 1, "Genre:", genreField);
        addFormField(panel, gbc, 2, 1, "Year:", yearField);
        addFormField(panel, gbc, 4, 1, "Total Copies:", totalCopiesField);

        return panel;
    }

    private void addFormField(JPanel panel, GridBagConstraints gbc, int x, int y, String label, JTextField field) {
        gbc.gridx = x;
        gbc.gridy = y;
        panel.add(new JLabel(label), gbc);
        gbc.gridx = x + 1;
        panel.add(field, gbc);
    }

    private JPanel buildTablePanel() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));

        // Search bar
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchField = new JTextField(20);
        JButton searchBtn = new JButton("Search (Title/Author/Genre)");
        JButton availableBtn = new JButton("Show Available Only");
        JButton showAllBtn = new JButton("Show All");
        searchBtn.addActionListener(e -> performSearch());
        availableBtn.addActionListener(e -> {
            populateTable(catalogManager.getAvailableBooks());
            setStatus("Showing books with at least one available copy.", false);
        });
        showAllBtn.addActionListener(e -> refreshTable());
        searchPanel.add(new JLabel("Search:"));
        searchPanel.add(searchField);
        searchPanel.add(searchBtn);
        searchPanel.add(availableBtn);
        searchPanel.add(showAllBtn);

        tableModel = new DefaultTableModel(COLUMNS, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // table is read-only; edits happen via form
            }
        };
        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getSelectionModel().addListSelectionListener(this::onRowSelected);

        panel.add(searchPanel, BorderLayout.NORTH);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }

    private JPanel buildButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout());

        JButton addBtn = new JButton("Add");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete");
        JButton checkoutBtn = new JButton("Check Out");
        JButton returnBtn = new JButton("Return");
        JButton clearBtn = new JButton("Clear Form");

        addBtn.addActionListener(e -> handleAdd());
        updateBtn.addActionListener(e -> handleUpdate());
        deleteBtn.addActionListener(e -> handleDelete());
        checkoutBtn.addActionListener(e -> handleCheckout());
        returnBtn.addActionListener(e -> handleReturn());
        clearBtn.addActionListener(e -> clearForm());

        statusLabel = new JLabel("Ready.");
        statusLabel.setBorder(BorderFactory.createEmptyBorder(0, 15, 0, 0));

        panel.add(addBtn);
        panel.add(updateBtn);
        panel.add(deleteBtn);
        panel.add(checkoutBtn);
        panel.add(returnBtn);
        panel.add(clearBtn);
        panel.add(statusLabel);
        return panel;
    }

    // ---------------------------------------------------------------
    // Event handlers
    // ---------------------------------------------------------------

    private void handleAdd() {
        try {
            int totalCopies = parseIntField(totalCopiesField, "Total Copies");
            Book book = new Book(
                    isbnField.getText().trim(),
                    titleField.getText().trim(),
                    authorField.getText().trim(),
                    genreField.getText().trim(),
                    parseIntField(yearField, "Year"),
                    totalCopies
            );
            catalogManager.addBook(book);
            refreshTable();
            clearForm();
            setStatus("Book '" + book.getTitle() + "' added successfully.", false);
        } catch (InvalidBookDataException ex) {
            showError(ex.getMessage());
        }
    }

    private void handleUpdate() {
        try {
            String isbn = isbnField.getText().trim();
            Book existing = catalogManager.getBookByIsbn(isbn);
            if (existing == null) {
                showError("No book found with ISBN '" + isbn + "'. Select a row first.");
                return;
            }
            int totalCopies = parseIntField(totalCopiesField, "Total Copies");
            // Preserve currently checked-out copies when the total changes.
            int checkedOut = existing.getTotalCopies() - existing.getAvailableCopies();
            int newAvailable = Math.max(0, totalCopies - checkedOut);

            Book updated = new Book(
                    isbn,
                    titleField.getText().trim(),
                    authorField.getText().trim(),
                    genreField.getText().trim(),
                    parseIntField(yearField, "Year"),
                    totalCopies,
                    newAvailable
            );
            catalogManager.updateBook(updated);
            refreshTable();
            clearForm();
            setStatus("Book '" + updated.getIsbn() + "' updated successfully.", false);
        } catch (InvalidBookDataException ex) {
            showError(ex.getMessage());
        }
    }

    private void handleDelete() {
        String isbn = isbnField.getText().trim();
        if (isbn.isEmpty()) {
            showError("Enter or select an ISBN to delete.");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete book with ISBN '" + isbn + "'?", "Confirm Delete",
                JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            boolean removed = catalogManager.deleteBook(isbn);
            if (removed) {
                refreshTable();
                clearForm();
                setStatus("Book '" + isbn + "' deleted.", false);
            } else {
                showError("No book found with ISBN '" + isbn + "'.");
            }
        }
    }

    private void handleCheckout() {
        String isbn = isbnField.getText().trim();
        if (isbn.isEmpty()) {
            showError("Enter or select an ISBN to check out.");
            return;
        }
        try {
            catalogManager.checkout(isbn);
            refreshTable();
            setStatus("Checked out one copy of ISBN '" + isbn + "'.", false);
        } catch (InvalidBookDataException ex) {
            showError(ex.getMessage());
        }
    }

    private void handleReturn() {
        String isbn = isbnField.getText().trim();
        if (isbn.isEmpty()) {
            showError("Enter or select an ISBN to return.");
            return;
        }
        try {
            catalogManager.returnBook(isbn);
            refreshTable();
            setStatus("Returned one copy of ISBN '" + isbn + "'.", false);
        } catch (InvalidBookDataException ex) {
            showError(ex.getMessage());
        }
    }

    private void performSearch() {
        String keyword = searchField.getText().trim();
        if (keyword.isEmpty()) {
            refreshTable();
            return;
        }
        List<Book> results = catalogManager.search(keyword);
        populateTable(results);
        setStatus(results.size() + " result(s) found.", false);
    }

    private void onRowSelected(ListSelectionEvent e) {
        if (e.getValueIsAdjusting()) return;
        int row = table.getSelectedRow();
        if (row < 0) return;

        isbnField.setText(tableModel.getValueAt(row, 0).toString());
        titleField.setText(tableModel.getValueAt(row, 1).toString());
        authorField.setText(tableModel.getValueAt(row, 2).toString());
        genreField.setText(tableModel.getValueAt(row, 3).toString());
        yearField.setText(tableModel.getValueAt(row, 4).toString());
        totalCopiesField.setText(tableModel.getValueAt(row, 5).toString());
    }

    // ---------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------

    private int parseIntField(JTextField field, String fieldName) throws InvalidBookDataException {
        try {
            return Integer.parseInt(field.getText().trim());
        } catch (NumberFormatException ex) {
            throw new InvalidBookDataException(fieldName + " must be a whole number.");
        }
    }

    private void refreshTable() {
        populateTable(catalogManager.getAllBooks());
        setStatus(catalogManager.getTotalTitles() + " title(s) | " +
                catalogManager.getTotalAvailable() + "/" + catalogManager.getTotalCopies() +
                " copies available", false);
    }

    private void populateTable(List<Book> books) {
        tableModel.setRowCount(0);
        for (Book b : books) {
            tableModel.addRow(new Object[]{
                    b.getIsbn(), b.getTitle(), b.getAuthor(), b.getGenre(),
                    b.getYear(), b.getTotalCopies(), b.getAvailableCopies()
            });
        }
    }

    private void clearForm() {
        isbnField.setText("");
        titleField.setText("");
        authorField.setText("");
        genreField.setText("");
        yearField.setText("");
        totalCopiesField.setText("");
        table.clearSelection();
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
        setStatus(message, true);
    }

    private void setStatus(String message, boolean isError) {
        statusLabel.setText(message);
        statusLabel.setForeground(isError ? Color.RED : new Color(0, 100, 0));
    }

    // ---------------------------------------------------------------
    // Entry point
    // ---------------------------------------------------------------

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
            // Fall back to default look and feel
        }
        SwingUtilities.invokeLater(() -> new LibraryCatalogTool().setVisible(true));
    }
}
