# Library Catalog Tool

A desktop **Library Catalog Management Tool** built in core Java with a Swing GUI, developed as part of my **CODTECH IT Solutions Internship** (Java domain).

## Overview

This application lets a librarian manage a book catalog through a graphical interface — adding titles, tracking copies, checking books in/out, and searching the collection. Data is persisted to a local CSV file, so the catalog survives between runs.

## Features

- **Add / Update / Delete** book records
- **Check Out / Return** — tracks available vs. total copies per title, and prevents checking out a book with zero copies left
- **Search** by title, author, or genre (partial, case-insensitive match)
- **Filter to available-only** titles with one click
- **Data persistence** to `catalog.csv` (auto-loaded on startup, auto-saved on every change)
- **Input validation** with a custom checked exception (`InvalidBookDataException`) — e.g. ISBN format, valid publication year, non-negative copy counts
- **Live stats** in the status bar (total titles, copies available vs. total)

## Concepts Demonstrated

| Concept | Where |
|---|---|
| OOP (encapsulation, constructor overloading) | `Book.java` |
| Custom exceptions | `InvalidBookDataException.java` |
| Collections Framework (`ArrayList`, `HashMap`) | `LibraryCatalogManager.java` |
| File I/O (`BufferedReader`/`BufferedWriter`) | `LibraryCatalogManager.java` |
| Swing GUI, layout managers (`GridBagLayout`, `BorderLayout`, `FlowLayout`) | `LibraryCatalogTool.java` |
| Delegation Event Model (`ActionListener`, `ListSelectionListener`) | `LibraryCatalogTool.java` |
| Lambda expressions & method references | Event handlers, `Comparator` |

## Project Structure

```
LibraryCatalogTool/
├── src/
│   ├── Book.java                     # Model class
│   ├── InvalidBookDataException.java # Custom exception
│   ├── LibraryCatalogManager.java    # CRUD + checkout/return logic + persistence
│   └── LibraryCatalogTool.java       # Swing GUI (entry point)
├── catalog.csv                       # Auto-generated data file (created on first run)
└── README.md
```

## How to Run

**Requirements:** JDK 8 or higher.

```bash
# 1. Compile
cd LibraryCatalogTool
javac -d bin src/*.java

# 2. Run
cd bin
java LibraryCatalogTool
```

The app will create `catalog.csv` in the working directory the first time you add a book.

## Usage

1. Fill in the book details in the form at the top (ISBN, Title, Author, Genre, Year, Total Copies).
2. Click **Add** to catalog a new title.
3. Click a row in the table to load it into the form, then **Update** or **Delete** it.
4. Select a row (or type its ISBN) and click **Check Out** / **Return** to adjust available copies.
5. Use the search bar to filter by title, author, or genre; use **Show Available Only** to see what's currently on the shelf; **Show All** resets the view.

## Author

**Abhay** — B.Tech IT, Amity University Madhya Pradesh
CODTECH Internship — Java Programming Domain
